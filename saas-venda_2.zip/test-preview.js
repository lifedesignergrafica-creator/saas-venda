const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });

  // Test 1: normal conditions (CDNs reachable)
  {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto('file://' + path.resolve(__dirname, 'preview.html'));
    await page.click('text=Entrar como Administrador');
    await page.waitForTimeout(300);
    const dashboardVisible = await page.locator('text=Dashboard').first().isVisible().catch(() => false);
    console.log('TEST 1 (CDN ok) — dashboard visible:', dashboardVisible, '| JS errors:', errors);
    await page.close();
  }

  // Test 2: simulate no internet (block all CDN requests) — worst case for the user's environment
  {
    const context = await browser.newContext();
    await context.route('**://cdnjs.cloudflare.com/**', (route) => route.abort());
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto('file://' + path.resolve(__dirname, 'preview.html'));
    await page.click('text=Entrar como Administrador');
    await page.waitForTimeout(300);
    const dashboardVisible = await page.locator('text=Dashboard').first().isVisible().catch(() => false);
    console.log('TEST 2 (CDN blocked / offline) — dashboard visible:', dashboardVisible, '| JS errors:', errors);
    await page.screenshot({ path: '/tmp/test-offline.png' });
    await page.close();
  }

  await browser.close();
})();

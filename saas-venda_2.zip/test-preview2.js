const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (msg) => { if (msg.type() === 'error') errors.push('console: ' + msg.text()); });

  await page.goto('file://' + path.resolve(__dirname, 'preview.html'));
  await page.screenshot({ path: '/tmp/v2-login.png' });

  await page.click('text=Entrar como Administrador');
  await page.waitForTimeout(400);
  await page.screenshot({ path: '/tmp/v2-dashboard.png', fullPage: true });

  // Inventory + create product with photo
  await page.click('text=Estoque');
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/v2-inventory.png', fullPage: true });

  await page.click('text=Novo Produto');
  await page.waitForTimeout(200);
  await page.fill('#pm-name', 'Moletom Premium');
  await page.fill('#pm-price', '129.9');
  await page.fill('#pm-stock', '8');
  await page.fill('#pm-alert', '3');

  // create a tiny test image and upload it
  const imgPath = '/tmp/test-upload.png';
  const pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
  fs.writeFileSync(imgPath, Buffer.from(pngBase64, 'base64'));
  await page.setInputFiles('#pm-photo', imgPath);
  await page.waitForTimeout(200);
  await page.screenshot({ path: '/tmp/v2-modal-with-photo.png' });

  await page.click('text=Salvar Produto');
  await page.waitForTimeout(300);
  const productAdded = await page.locator('text=Moletom Premium').first().isVisible().catch(() => false);
  console.log('Product with photo added:', productAdded);
  await page.screenshot({ path: '/tmp/v2-inventory-after-add.png', fullPage: true });

  // Delete it to test exclude
  await page.click('text=Moletom Premium >> xpath=ancestor::div[contains(@class,"rounded-2xl")][1]//button[contains(., "Editar")]');
  await page.waitForTimeout(200);
  page.once('dialog', d => d.accept());
  await page.click('#product-modal-slot >> text=Excluir');
  await page.waitForTimeout(300);
  const productRemoved = !(await page.locator('text=Moletom Premium').first().isVisible().catch(() => false));
  console.log('Product removed after delete:', productRemoved);

  // POS check images render
  await page.click('text=PDV');
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/v2-pos.png', fullPage: true });

  // Users page
  await page.click('text=Usuários');
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/v2-users.png', fullPage: true });

  console.log('JS errors:', errors);
  await browser.close();
})();

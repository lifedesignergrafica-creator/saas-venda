const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  await context.route('**/*', (route) => {
    const url = route.request().url();
    if (url.startsWith('file://')) return route.continue();
    return route.abort();
  });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  await page.goto('file://' + path.resolve(__dirname, 'preview.html'));
  await page.click('text=Entrar como Administrador');
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/final-dashboard.png', fullPage: true });

  await page.click('#nav-links >> text=Estoque');
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/final-inventory.png', fullPage: true });

  await page.click('text=Novo Produto');
  await page.waitForTimeout(200);
  await page.fill('#pm-name', 'Moletom Premium');
  await page.fill('#pm-price', '129.9');
  await page.fill('#pm-stock', '8');
  await page.fill('#pm-alert', '3');

  const imgPath = '/tmp/test-upload.png';
  const pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
  fs.writeFileSync(imgPath, Buffer.from(pngBase64, 'base64'));
  await page.setInputFiles('#pm-photo', imgPath);
  await page.waitForTimeout(200);
  await page.screenshot({ path: '/tmp/final-modal.png' });

  await page.click('text=Salvar Produto');
  await page.waitForTimeout(300);
  const added = await page.locator('text=Moletom Premium').first().isVisible().catch(() => false);
  console.log('Produto com foto adicionado:', added);
  await page.screenshot({ path: '/tmp/final-inventory-after.png', fullPage: true });

  await page.click('#nav-links >> text=PDV');
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/final-pos.png', fullPage: true });

  await page.click('#nav-links >> text=Usuários');
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/final-users.png', fullPage: true });

  console.log('Erros JS:', errors);
  await browser.close();
})();

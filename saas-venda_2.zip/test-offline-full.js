const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  // Block ALL external network requests to simulate a fully offline / restricted environment
  await context.route('**/*', (route) => {
    const url = route.request().url();
    if (url.startsWith('file://')) return route.continue();
    return route.abort();
  });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  await page.goto('file://' + path.resolve(__dirname, 'preview.html'));
  await page.waitForTimeout(300);
  await page.screenshot({ path: '/tmp/offline-login.png' });

  await page.click('text=Entrar como Administrador');
  await page.waitForTimeout(300);
  const loginHidden = await page.locator('#view-login').isHidden();
  const appVisible = await page.locator('#view-app').isVisible();
  console.log('OFFLINE TEST — login hidden:', loginHidden, '| app visible:', appVisible, '| errors:', errors);
  await page.screenshot({ path: '/tmp/offline-dashboard.png', fullPage: true });

  await browser.close();
})();

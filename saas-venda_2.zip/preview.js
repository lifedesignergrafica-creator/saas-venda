const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  // 1. Login page (unauthenticated)
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.screenshot({ path: '/tmp/shot-login.png' });

  // Seed auth (bypass Google OAuth for preview) + seed IndexedDB data
  await page.evaluate(() => {
    const user = {
      id: 'admin-1',
      name: 'Helber Admin',
      email: 'grupoimpresso2012@gmail.com',
      role: 'ADMIN',
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem(
      'saas_venda_auth',
      JSON.stringify({ state: { currentUser: user, accessToken: null }, version: 0 })
    );
  });

  // Seed some products/sales via IndexedDB directly (Dexie schema: saas_store_db)
  await page.evaluate(async () => {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('saas_store_db');
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('users')) db.createObjectStore('users', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('products')) db.createObjectStore('products', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('sales')) db.createObjectStore('sales', { keyPath: 'id' });
      };
      req.onsuccess = () => {
        const db = req.result;
        const tx = db.transaction(['users', 'products', 'sales'], 'readwrite');
        tx.objectStore('users').put({
          id: 'admin-1', name: 'Helber Admin', email: 'grupoimpresso2012@gmail.com',
          role: 'ADMIN', createdAt: new Date(),
        });
        tx.objectStore('users').put({
          id: 'att-1', name: 'Maria Souza', email: 'maria@example.com',
          role: 'ATTENDANT', createdAt: new Date(),
        });
        const products = [
          { id: 'p1', name: 'Camiseta Básica Branca', imageUrl: '', price: 49.9, stockQuantity: 24, minStockAlert: 5, createdAt: new Date(), updatedAt: new Date() },
          { id: 'p2', name: 'Caneca Personalizada', imageUrl: '', price: 29.9, stockQuantity: 3, minStockAlert: 5, createdAt: new Date(), updatedAt: new Date() },
          { id: 'p3', name: 'Boné Trucker', imageUrl: '', price: 59.9, stockQuantity: 12, minStockAlert: 4, createdAt: new Date(), updatedAt: new Date() },
          { id: 'p4', name: 'Ecobag Estampada', imageUrl: '', price: 34.5, stockQuantity: 0, minStockAlert: 5, createdAt: new Date(), updatedAt: new Date() },
          { id: 'p5', name: 'Adesivo Kit 10un', imageUrl: '', price: 14.9, stockQuantity: 40, minStockAlert: 10, createdAt: new Date(), updatedAt: new Date() },
        ];
        products.forEach((p) => tx.objectStore('products').put(p));
        tx.objectStore('sales').put({
          id: 's1', attendantId: 'admin-1', totalAmount: 109.7, paymentMethod: 'PIX',
          createdAt: new Date(),
          items: [
            { productId: 'p1', productName: 'Camiseta Básica Branca', quantity: 1, unitPrice: 49.9, totalPrice: 49.9 },
            { productId: 'p3', productName: 'Boné Trucker', quantity: 1, unitPrice: 59.9, totalPrice: 59.9 },
          ],
        });
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      };
      req.onerror = () => reject(req.error);
    });
  });

  // 2. Dashboard
  await page.goto('http://localhost:3000/dashboard', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.screenshot({ path: '/tmp/shot-dashboard.png', fullPage: true });

  // 3. Inventory
  await page.goto('http://localhost:3000/dashboard/inventory', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.screenshot({ path: '/tmp/shot-inventory.png', fullPage: true });

  // 4. Users
  await page.goto('http://localhost:3000/dashboard/users', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.screenshot({ path: '/tmp/shot-users.png', fullPage: true });

  // 5. POS
  await page.goto('http://localhost:3000/pos', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.screenshot({ path: '/tmp/shot-pos.png', fullPage: true });

  await browser.close();
  console.log('done');
})();
